## Entropy based wordle solver

CLI built with Typer

## Installation
#### Install dependencies
Run
```
pip install -r requirements.txt
```
